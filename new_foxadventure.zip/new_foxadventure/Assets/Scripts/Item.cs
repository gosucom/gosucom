﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    public int score = 10;
    void Start()
    {

    }

    void Update()
    {

    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log(gameObject.name + ".OnTriggerEnter2D:" + collision.name);
        Dynamic_new dynamic = collision.gameObject.GetComponent<Dynamic_new>();

        if (collision.gameObject.tag == "Player")
        {
            dynamic.score += score;
            Destroy(this.gameObject);
        }
    }
}
