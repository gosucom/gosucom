﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dynamic_new : MonoBehaviour
{
    public float JumpPower;
    public float speed;
    public bool isGround;
    public float score;
    public bool isJump;
    public bool isSadari;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //이동 : 시간에 따라 위치가 변경되는 것
        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.position += Vector3.right * Time.deltaTime * speed;
        }

        if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.position += Vector3.left * Time.deltaTime * speed;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (!isJump)
            {
                Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();
                rigidbody.velocity = Vector2.zero;
                rigidbody.AddForce(Vector3.up * JumpPower);
                isJump = true;
            }
        }

        if(Input.GetKey(KeyCode.UpArrow))
        {
            if (isSadari)
            {
                Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();
                rigidbody.velocity = Vector2.up;
            }
        }
 
        if (Input.GetKey(KeyCode.DownArrow))
        {
            if (isSadari)
            {
                Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();
                rigidbody.velocity = Vector2.down;
            }
        }
        /*if (Input.GetKey(KeyCode.UpArrow))
        {
            if (isSadari)
            {
                Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();
                transform.position += Vector3.up * Time.deltaTime * speed;
                rigidbody.gravityScale = 0;
            }
        }*/
    }
    private void OnGUI()
    {
        GUI.Box(new Rect(0, 0, 200, 20), "score:" + score);
    }
   
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name != "ground")
            Debug.Log("OnCollisionEnter2D:" + collision.gameObject.name);
        if (collision.gameObject.tag == "Object")
        {
            Destroy(collision.gameObject);
            if (collision.gameObject.name == "crate")
                score++;
        }
        isJump = false;
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        Debug.Log("OnCollisionExit2D:" + collision.gameObject.name);
        //isground = false;
    }
   private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("OnTriggerEnter2D:" + collision.gameObject.name);
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        Debug.Log("OnTriggerStay2D:" + collision.gameObject.name);
        if (collision.gameObject.tag == "Sadari")
        {
            isSadari = true;
        }
        
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        Debug.Log("OnTriggerStay2D:" + collision.gameObject.name);
        if (collision.gameObject.tag == "Sadari")
        {
            isSadari = false;
        }

    }
}

